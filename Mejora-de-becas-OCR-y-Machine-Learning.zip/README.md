# Mejora-de-becas-OCR-y-Machine-Learning
Este es un proyecto usando OCR y machine learning, para mejorar el proceso de calificación de postulantes a Becas
